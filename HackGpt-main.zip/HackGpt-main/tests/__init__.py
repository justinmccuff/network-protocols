# HackGPT core module
